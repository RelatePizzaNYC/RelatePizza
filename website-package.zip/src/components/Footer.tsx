export default function Footer() {
  return (
    <footer className="bg-gray-50 border-t mt-12">
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h3 className="font-bold text-lg mb-4">Location</h3>
            <p>288 8th Ave</p>
            <p>New York, NY 10001</p>
          </div>

          <div>
            <h3 className="font-bold text-lg mb-4">Hours</h3>
            <p>Open Daily</p>
            <p>10:00 AM - 9:00 PM</p>
          </div>

          <div>
            <h3 className="font-bold text-lg mb-4">Contact</h3>
            <p>
              <a href="tel:+16468923002" className="hover:text-primary">
                (646) 892-3002
              </a>
            </p>
            <p>
              <a href="mailto:mds059737@gmail.com" className="hover:text-primary">
                mds059737@gmail.com
              </a>
            </p>
          </div>
        </div>

        <div className="mt-8 pt-8 border-t text-center text-sm text-gray-500">
          © {new Date().getFullYear()} Relate Pizza. All rights reserved.
        </div>
      </div>
    </footer>
  );
}