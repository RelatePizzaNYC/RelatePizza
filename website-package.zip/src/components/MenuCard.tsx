import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";

type MenuItem = {
  name: string;
  price: number;
};

type MenuCardProps = {
  title: string;
  items: MenuItem[];
};

export default function MenuCard({ title, items }: MenuCardProps) {
  return (
    <Card className="h-full">
      <CardHeader>
        <CardTitle className="text-xl font-bold">{title}</CardTitle>
        <CardDescription>All pizzas are 14 inch</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {items.map((item, index) => (
            <div key={index}>
              {index > 0 && <Separator className="my-4" />}
              <div className="flex justify-between items-center">
                <span className="font-medium">{item.name}</span>
                <span className="text-primary font-bold">
                  ${item.price.toFixed(2)}
                </span>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
