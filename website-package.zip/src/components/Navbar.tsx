import { Link } from "wouter";

export default function Navbar() {
  return (
    <nav className="border-b bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/60 sticky top-0 z-50">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <Link href="/">
          <a className="text-2xl font-bold text-primary">Relate Pizza</a>
        </Link>

        <div className="flex gap-6 items-center">
          <Link href="/menu">
            <a className="font-medium hover:text-primary transition-colors">Menu</a>
          </Link>
          <a href="tel:+16468923002" className="font-medium hover:text-primary">
            (646) 892-3002
          </a>
        </div>
      </div>
    </nav>
  );
}