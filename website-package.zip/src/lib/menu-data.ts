export const menuItems = {
  classics: [
    { name: "Cheese Pizza", price: 12.00 },
    { name: "Beef Pepperoni Pizza", price: 20.00 },
    { name: "Sausage Pizza", price: 24.00 },
    { name: "White Pizza", price: 24.00 }
  ],
  specialties: [
    { name: "Meat Lovers Pizza", price: 40.00 },
    { name: "Supreme Pizza", price: 40.00 },
    { name: "Meatball & Ricotta", price: 32.00 },
    { name: "Chicken & Broccoli", price: 40.00 }
  ],
  combos: [
    { name: "Sausage & Pepperoni", price: 28.00 },
    { name: "Pineapple & Pepperoni", price: 28.00 },
    { name: "Bacon & Pepperoni", price: 28.00 },
    { name: "Mushroom & Pepperoni", price: 28.00 }
  ],
  chicken: [
    { name: "Classic Chicken", price: 32.00 },
    { name: "BBQ Chicken", price: 36.00 },
    { name: "Buffalo Chicken", price: 36.00 },
    { name: "Chicken Bacon Ranch", price: 32.00 }
  ],
  vegetarian: [
    { name: "Veggie Supreme", price: 28.00 },
    { name: "Mushroom & Olive", price: 28.00 },
    { name: "Broccoli & Ricotta", price: 28.00 },
    { name: "Spinach & Ricotta", price: 24.00 }
  ]
};
