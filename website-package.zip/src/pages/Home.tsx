import { Button } from "@/components/ui/button";
import { Link } from "wouter";

export default function Home() {
  return (
    <div>
      <section
        className="h-[70vh] bg-cover bg-center relative flex items-center"
        style={{
          backgroundImage: "linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.5)), url('https://images.unsplash.com/photo-1533777419517-3e4017e2e15a')"
        }}
      >
        <div className="container mx-auto px-4">
          <div className="max-w-2xl text-white">
            <h1 className="text-5xl font-bold mb-6">
              New York's Finest Pizza
            </h1>
            <p className="text-xl mb-8">
              Hand-tossed dough, fresh ingredients, and time-honored recipes make every pizza special.
            </p>
            <Button size="lg" asChild>
              <Link href="/menu">View Our Menu</Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="text-center">
              <img
                src="https://images.unsplash.com/photo-1513104890138-7c749659a591"
                alt="Fresh Pizza"
                className="w-full h-64 object-cover rounded-lg mb-4"
              />
              <h3 className="text-xl font-bold mb-2">Fresh Ingredients</h3>
              <p className="text-gray-600">
                We use only the freshest ingredients in all our pizzas
              </p>
            </div>

            <div className="text-center">
              <img
                src="https://images.unsplash.com/photo-1534308983496-4fabb1a015ee"
                alt="Traditional Methods"
                className="w-full h-64 object-cover rounded-lg mb-4"
              />
              <h3 className="text-xl font-bold mb-2">Traditional Methods</h3>
              <p className="text-gray-600">
                Hand-tossed dough made fresh daily
              </p>
            </div>

            <div className="text-center">
              <img
                src="https://images.unsplash.com/photo-1528137871618-79d2761e3fd5"
                alt="Perfect Taste"
                className="w-full h-64 object-cover rounded-lg mb-4"
              />
              <h3 className="text-xl font-bold mb-2">Perfect Taste</h3>
              <p className="text-gray-600">
                Experience authentic New York pizza
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl font-bold mb-8">Visit Us Today</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 text-left">
              <div>
                <h3 className="font-bold text-xl mb-2">Location</h3>
                <p>288 8th Ave<br />New York, NY 10001</p>
              </div>
              <div>
                <h3 className="font-bold text-xl mb-2">Hours</h3>
                <p>Open Daily<br />10:00 AM - 9:00 PM</p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}