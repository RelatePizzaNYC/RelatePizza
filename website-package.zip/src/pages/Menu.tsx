import MenuCard from "@/components/MenuCard";
import { menuItems } from "@/lib/menu-data";

export default function Menu() {
  return (
    <div className="container mx-auto px-4 py-12">
      <div className="max-w-3xl mx-auto text-center mb-12">
        <h1 className="text-4xl font-bold mb-4">Our Menu</h1>
        <p className="text-gray-600">
          All pizzas are made fresh to order with our signature sauce and premium mozzarella
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        <MenuCard title="Classic Pizzas" items={menuItems.classics} />
        <MenuCard title="Specialty Pizzas" items={menuItems.specialties} />
        <MenuCard title="Perfect Combos" items={menuItems.combos} />
        <MenuCard title="Chicken Pizzas" items={menuItems.chicken} />
        <MenuCard title="Vegetarian Options" items={menuItems.vegetarian} />
      </div>

      <div className="mt-12 bg-gray-50 rounded-lg p-8 text-center">
        <h3 className="text-xl font-bold mb-4">Visit Us In-Store</h3>
        <p className="mb-6">Stop by our location for fresh, hot pizza made to order</p>
        <p className="font-medium text-lg">
          288 8th Ave, New York, NY 10001<br />
          <a href="tel:+16468923002" className="text-primary hover:text-primary/90">
            (646) 892-3002
          </a>
        </p>
      </div>
    </div>
  );
}